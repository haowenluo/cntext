- [ ] 增加4个函数，封装tomotopy的LDAModel HDPModel CTModel DTM
      -  函数接受参数csvf ，csvf含date、text、label三列
      -  函数接受参数词语与topic_id的映射关系，增加输出的topic_id的可解读性
      -  函数内预处理中英文，保存为缓存文件。如果检查到有缓存文件， 直接读取缓存
      -  函数检查是否有缓存模型文件，如果有，直接读取模型文件
      -  可视化，支持中文， 使用plotnine

      https://bab2min.github.io/tomotopy/v0.13.0/en/index.html#examples


- [ ] 增加BERT训练，支持中英文



- [ ] 构建文本因果分析模型，支持潜变量。

