import numpy as np
from numpy.linalg import norm
import scipy.spatial.distance
import itertools








def project_word(wv, a, b):
    """
    计算词语a在词语b上的投影

    Args:
        wv (KeyedVectors): 语言模型的KeyedVectors
        a : 词语a字符串或列表
        b:  词语b字符串或列表

    Returns:
        float: 词语a在词语b上的投影
    """

    # 计算向量 A 和向量 B
    if isinstance(a, str):
        vec_a = wv[a]
    else:
        vec_a = wv.get_mean_vector(a)

    if isinstance(b, str):
        vec_b = wv[b]
    else:
        vec_b = wv.get_mean_vector(b)
    

    return np.dot(vec_a, vec_b) / np.linalg.norm(vec_b)

        
    

            
            
        
        

    



def generate_concept_axis(wv, c_words1, c_words2):
    """
    生成概念轴向量。

    参数:
    - wv(KeyedVectors): : 包含预训练的词向量。
    - c_words1(list): 第一个词语列表，表示概念1。
    - c_words2(list): 第二个词语列表，表示概念2。

    返回:
    - concept_axis: 概念轴向量，表示从概念2到概念1的方向。
    """
    # 计算两个概念的平均向量
    vector1 = wv.get_mean_vector(c_words1)
    vector2 = wv.get_mean_vector(c_words2)

    # 计算概念轴
    concept_axis = vector1 - vector2

    # 归一化（可选）
    return concept_axis



def intersection_align_gensim(wv1, wv2, words=None):
    """
    计算两个gensim模型的交集，只保留两个模型的共有的词。

    Args:
        wv1 (KeyedVectors):  模型1的KeyedVectors
        wv2 (KeyedVectors): 模型2的KeyedVectors
        words (list, optional): 是否根据词典words对模型进行对齐， 对齐结束后的模型中含有的词不会超出words的范围； 默认None.

    Returns:
        List(KeyedVectors): 
    """

    # Get the vocab for each model
    vocab_wv1 = set(wv1.index_to_key)
    vocab_wv2 = set(wv2.index_to_key)
    #vocab_wv1 = set(wv1.wv.index_to_key)
    #vocab_wv2 = set(wv2.wv.index_to_key)

    # Find the common vocabulary
    common_vocab = vocab_wv1 & vocab_wv2
    if words: common_vocab &= set(words)

    # If no alignment necessary because vocab is identical...
    if not vocab_wv1 - common_vocab and not vocab_wv2 - common_vocab:
        return (wv1,wv2)

    # Otherwise sort by frequency (summed for both)
    common_vocab = list(common_vocab)
    common_vocab.sort(key=lambda w: wv1.get_vecattr(w, "count") + wv2.get_vecattr(w, "count"), reverse=True)
    # print(len(common_vocab))

    # Then for each model...
    for wvn in [wv1, wv2]:
        # Replace old syn0norm array with new one (with common vocab)
        indices = [wvn.key_to_index[w] for w in common_vocab]
        old_arr = wvn.vectors
        new_arr = np.array([old_arr[index] for index in indices])
        wvn.vectors = new_arr

        # Replace old vocab dictionary with new one (with common vocab)
        # and old index2word with new one
        new_key_to_index = {}
        new_index_to_key = []
        for new_index, key in enumerate(common_vocab):
            new_key_to_index[key] = new_index
            new_index_to_key.append(key)
        wvn.key_to_index = new_key_to_index
        wvn.index_to_key = new_index_to_key

    return (wv1,wv2)


def procrustes_align(base_wv, other_wv, words=None):
    """
    使用Procrustes算法对齐两个嵌入模型，以方便进行两个模型中语义比较的数据分析
    
    参考资料: 
       https://github.com/williamleif/histwords
       https://gist.github.com/quadrismegistus/09a93e219a6ffc4f216fb85235535faf
    
    Args:
        base_wv (gensim.models.keyedvectors.KeyedVectors): 基准语言模型
        other_wv (gensim.models.keyedvectors.KeyedVectors): 其他语言模型
        words (list, optional): 是否根据词典words对模型进行对齐， 对齐结束后的模型中含有的词不会超出words的范围； 默认None.
        
    Returns:
        _type_: _description_
    """

    # patch by Richard So [https://twitter.com/richardjeanso) (thanks!) to update this code for new version of gensim
    # base_wv.init_sims(replace=True)
    # other_wv.init_sims(replace=True)

    # make sure vocabulary and indices are aligned
    in_base_wv, in_other_wv = intersection_align_gensim(base_wv, other_wv, words=words)

    # re-filling the normed vectors
    in_base_wv.fill_norms(force=True)
    in_other_wv.fill_norms(force=True)

    # get the (normalized) embedding matrices
    base_vecs = in_base_wv.get_normed_vectors()
    other_vecs = in_other_wv.get_normed_vectors()

    # just a matrix dot product with numpy
    m = other_vecs.T.dot(base_vecs) 
    # SVD method from numpy
    u, _, v = np.linalg.svd(m)
    # another matrix operation
    ortho = u.dot(v) 
    # Replace original array with modified one, i.e. multiplying the embedding matrix by "ortho"
    other_wv.vectors = (in_other_wv.vectors).dot(ortho)    
    
    return other_wv



def semantic_centroid(wv, words):
    """
    计算多个词语的语义中心向量
    
    Args:
        wv (gensim.models.keyedvectors.KeyedVectors): 词向量模型
        words (list): 词语列表

    Returns:
        np.array: 语义中心向量
    """
    container = np.zeros(wv.vector_size)
    valid_words = 0  # 记录有效词的数量

    for word in words:
        try:
            container += wv.get_vector(word)
            valid_words += 1
        except KeyError:  # 忽略不在模型中的词
            continue
    if valid_words == 0:  # 如果没有有效词，返回零向量
        return container

    centroid = container / valid_words
    # 归一化语义中心向量
    norm_centroid = centroid / np.linalg.norm(centroid) if np.linalg.norm(centroid) != 0 else centroid
    return norm_centroid



    

def sematic_projection(wv, words, c_words1, c_words2):
    """
    计算词语在概念向量上的投影长度。 投影长度大于0表示语义上更接近c_words2。
    
    注意概念向量轴是由c_words1和c_words2定义的。
   
    参考Grand, G., Blank, I.A., Pereira, F. and Fedorenko, E., 2022. Semantic projection recovers rich human knowledge of multiple object features from word embeddings. _Nature Human Behaviour_, pp.1-13.

    Args:
        wv (gensim.models.keyedvectors.KeyedVectors):  词向量模型
        words (list): 词语列表; animals = ['cat', 'dog', 'mouse']
        c_words1 (list): 词语列表;  c_words1 = ["small", "little", "tiny"]
        c_words2 (list): 词语列表;  c_words2 = ["large", "big", "huge"]

    Returns:
        list: 词语在概念向量上的投影长度列表
    """

    projection_scores = []
    #确保词语在向量模型中
    source_vector = wv.get_mean_vector(c_words1)
    target_vector = wv.get_mean_vector(c_words2)
    c_vector = target_vector - source_vector
    concept_norm = norm(c_vector)
    for word in words:
        any_vector = wv.get_vector(word)
        projection_score = np.dot(any_vector, c_vector) / concept_norm
        projection_scores.append((word, round(projection_score, 2)))
        
    projection_scores = sorted(projection_scores, key=lambda k:k[1], reverse=False)
    return projection_scores

    
    
def sematic_distance(wv, words, c_words1, c_words2):
    """
    计算语义距离。 该函数计算结果如果大于0， 表示语义上更接近c_words2。

    Args:
        wv (gensim.models.keyedvectors.KeyedVectors): 词向量模型
        words (list):   词语列表;  words = ['program','software', 'computer']
        c_words1 (list):  词语列表; c_words1 = ["man", "he", "him"]
        c_words2 (list):  词语列表; c_words2 = ["woman", "she", "her"]
        
    Returns:
        float: 该函数计算结果如果大于0， 表示语义上更接近c_words2。
        
        
    words = ['program','software', 'computer']
    c_words1 = ["man", "he", "him"]
    c_words2 = ["woman", "she", "her"]
    dist(words, c_words1) = ||any_vector - c_vector1||
    dist(words, c_words2) = ||any_vector - c_vector2||
    result = dist(words_centroid_vector, c_centroid_vector1) - dist(words_centroid_vector, c_centroid_vector2)
    
    if result > 0, 表示语义上更接近c_words2
    if result < 0, 表示语义上更接近c_words1
    """
    
    any_vector = wv.get_mean_vector(words)
    c_vector1 = wv.get_mean_vector(c_words1)
    c_vector2 = wv.get_mean_vector(c_words2)
    dist_1 = np.linalg.norm(any_vector - c_vector1)
    dist_2 = np.linalg.norm(any_vector - c_vector2)
    res = dist_1 - dist_2
    return round(res, 2)



def divergent_association_task(wv, words, minimum=7):
    """
    计算DAT分数

    参考资料:
        Olson, J. A., Nahas, J., Chmoulevitch, D., Cropper, S. J., & Webb, M. E. (2021). Naming unrelated words predicts creativity. Proceedings of the National Academy of Sciences, 118(25), e2022340118.

    Args:
        wv (gensim.models.keyedvectors.KeyedVectors): 词向量模型
        words (list): 词语列表;  words = ['program', 'software', 'computer']
        minimum (int, optional):  词语列表长度; Defaults to 7.

    Returns:
        float: DAT分数
    """
  
    # Keep only valid unique words
    uniques = []
    for word in words:
        try:
            wv.get_vector(word)
            uniques.append(word)
        except:
            pass
    

    # Keep subset of words
    if len(uniques) >= minimum:
        subset = uniques[:minimum]
    else:
        return None # Not enough valid words

    # Compute distances between each pair of words
    distances = []
    for word1, word2 in itertools.combinations(subset, 2):
        dist = scipy.spatial.distance.cosine(wv.get_vector(word1), wv.get_vector(word2))
        distances.append(dist)

    # Compute the DAT score (average semantic distance multiplied by 100)
    return (sum(distances) / len(distances)) * 100



def discursive_diversity_score(wv, words):
    """
    计算话语多样性得分
    
    参考资料:
        Lix, Katharina, Amir Goldberg, Sameer B. Srivastava, and Melissa A. Valentine. “Aligning differences: Discursive diversity and team performance.” Management Science 68, no. 11 (2022): 8430-8448.

    Args:
        wv (gensim.models.keyedvectors.KeyedVectors):   词向量模型
        words (list): 词语列表;  words = ['program','software', 'computer']

    Returns:
        float: 话语多样性得分
    """

    # 计算词嵌入向量的平均值
    embedding_vectors = []
    for word in words:
        try:
            embedding_vectors.append(wv.get_vector(word))
        except:
            pass
    centroid = np.mean(embedding_vectors, axis=0)
    
    # 计算词嵌入向量之间的余弦相似度
    pairwise_distances = [np.dot(centroid, embedding) / (np.linalg.norm(centroid) * np.linalg.norm(embedding)) for embedding in embedding_vectors]
    
    # 计算语言多样性得分
    diversity_score = np.mean(pairwise_distances)
    
    return diversity_score