"""
使用csv数据，其中文本字段名可能是doc、content、text。

通过读取csv, 预处理中英文(可参考model.utils.preprocess_line）， 自动寻找最佳的topic数，实现LDA、动态主题模型​。
"""