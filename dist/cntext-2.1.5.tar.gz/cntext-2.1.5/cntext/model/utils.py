from collections import defaultdict
from pathlib import Path
import numpy as np
import jieba
from ..io.dict import read_yaml_dict
from gensim.models import KeyedVectors
from gensim.scripts.glove2word2vec import glove2word2vec as glove2wv
from gensim.models import fasttext
from nltk.tokenize import word_tokenize
import pandas as pd
import multiprocessing
import psutil  # 用于获取系统内存信息
import re
import logging
import platform
# 在文件开头添加
jieba_logger = logging.getLogger('jieba')
jieba_logger.setLevel(logging.CRITICAL)
    
    
    
    
def get_optimal_threshold():
    """根据系统总内存动态调整内存阈值"""
    total_mem = psutil.virtual_memory().total / (1024 ** 3)  # 获取总内存，单位GB
    used_mem = psutil.virtual_memory().used / (1024 ** 3)    # 获取已用内存
    if total_mem < 8:
        return 0.5  # 小内存系统
    elif total_mem < 16:
        return 0.6  # 中等内存系统
    elif total_mem < 32:
        return 0.7  # 大内存系统
    elif total_mem < 64:
        return 0.8  # 非常大内存系统
    else:
        # 对于超大内存系统，如果当前内存使用率低于50%，则使用0.85，否则使用0.75
        return 0.85 if (used_mem / total_mem) < 0.5 else 0.75
    


def load_userdict(dict_file=None):
    """
    加载用户自定义词典。

    Args:
        dict_file (str): 词典txt文件路径。每行一个词
    """
    if dict_file:
        jieba.load_userdict(dict_file)
        
    system = platform.system()
    
    if system == 'Windows':
        print('Windows System, Unable Parallel Processing')
    else:
        print('Mac(Linux) System, Enable Parallel Processing')
        jieba.enable_parallel(multiprocessing.cpu_count())
    
    
def load_stopwords(stopwords_file=None, lang='chinese'):
    """
    加载停用词。
    
    Args:
        stopwords_file (str): 停用词txt文件路径。每行一个词
        
    Returns:
        set: 停用词集合。
    """

    if lang == 'chinese':
        if stopwords_file:
            with open(stopwords_file, 'r', encoding='utf-8') as f:
                stopwords = set(f.read().splitlines())
        else:
            stopwords = set(read_yaml_dict(yfile='enzh_common_StopWords.yaml')['Dictionary']['chinese'])
    elif lang == 'english':
        if stopwords_file:
            with open(stopwords_file, 'r', encoding='utf-8') as f:
                stopwords = set(f.read().splitlines())
        else:
            stopwords = set(read_yaml_dict(yfile='enzh_common_StopWords.yaml')['Dictionary']['english'])
    else:
        raise ValueError(f"Unsupported language: {lang}")
    return stopwords

            
    
#常见符号
punctuation = '＂＃＄％＆＇（）＊＋，－／：；＜＝＞＠［＼］＾＿｀｛｜｝～｟｠｢｣､\u3000、〃〈〉《》「」『』【】〔〕〖〗〘〙〚〛〜〝〞〟〰〾〿–—‘’‛“”„‟…‧﹏﹑﹔·．！？｡。'

def preprocess_line(line, lang='chinese', stopwords=None):
    """
    根据语言对单行文本进行预处理。
    
    Args:
        line (str): 输入的一行文本。
        lang (str): 语言类型，支持 'chinese' 或 'english'。
        stopwords (set): 停用词集合。
        
    Returns:
        list: 预处理后的分词结果。
    """
    # 去除首尾空格并检查空行
    line = line.strip()
    if not line:
        return []
    
    # 将停用词转换为frozenset
    stopwords = frozenset(stopwords) if stopwords else frozenset()

    if lang == 'chinese':
        line = re.sub(f'[^{punctuation}\u4e00-\u9fa5a-zA-Z0-9]', '', line.lower())
        # 使用生成器表达式优化内存
        tokens = [word 
                  for word in (w.strip() for w in jieba.cut(line))
                  if word and word not in stopwords and len(word)>1]
    elif lang == 'english':
        # 使用生成器表达式优化内存
        line = re.sub(f'[^{punctuation}a-zA-Z0-9]', '', line.lower())
        tokens = [word for word in (w.strip() for w in word_tokenize(line))
                 if word and word not in stopwords]
    else:
        raise ValueError(f"Unsupported language: {lang}")

    return tokens

######################################################################################################################

def co_occurrence_matrix(documents, window_size=2, lang='chinese'):
    """_summary_
    构建共词矩阵

    Args:
        documents (list): 文档列表
        window_size (int, optional):  共现范围. 默认2.
        lang (str, optional): 支持中英文，默认'chinese'.

    Returns:
        dict
    """
    d = defaultdict(int)
    vocab = set()
    if lang == 'english':
        for document in documents:
            document = document.lower().split()
            for i in range(len(document)):
                token = document[i]
                vocab.add(token)  # add to vocab
                next_token = document[i + 1: i + 1 + window_size]
                for t in next_token:
                    key = tuple(sorted([t, token]))
                    d[key] += 1

    elif lang =='chinese':
        for document in documents:
            document = list(jieba.cut(document))
            # iterate over sentences
            for i in range(len(list(document))):
                token = document[i]
                vocab.add(token)  # add to vocab
                next_token = document[i + 1: i + 1 + window_size]
                for t in next_token:
                    key = tuple(sorted([t, token]))
                    d[key] += 1
                    
    # formulate the dictionary into dataframe
    vocab = sorted(vocab)  # sort vocab
    df = pd.DataFrame(data=np.zeros((len(vocab), len(vocab)), dtype=np.int16),
                      index=vocab,
                      columns=vocab)
    for key, value in d.items():
        df.at[key[0], key[1]] = value
        df.at[key[1], key[0]] = value
    return df


######################################################################################   
        

def expand_dictionary(wv, seeddict, topn=100):
    """
    扩展词典, 结果保存到output文件夹内
    
    Args:
        wv (Word2VecKeyedVectors): 预训练模型，数据类型为 gensim.models.keyedvectors.KeyedVectors。
        seeddict (dict): 参数类似于种子词；格式为PYTHON字典；
                         examples seeddict = {'pos': ['happy', 'wonderful', 'good'],
                                              'neg': ['bad', 'ugly', 'terrible'}
        topn (int, optional): 返回topn个语义最接近seeddict的词，默认100.

    
    Returns:
    """
    resultdict = dict()
    for seed_name in seeddict.keys():
        seedwords = seeddict[seed_name]
        simidx_scores = []
        similars_candidate_idxs = [] #the candidate words of seedwords
        dictionary = wv.key_to_index
        seedidxs = [] #transform word to index
        for seed in seedwords:
            if seed in dictionary:
                seedidx = dictionary[seed]
                seedidxs.append(seedidx)
        for seedidx in seedidxs:
            # sims_words such as [('by', 0.99984), ('or', 0.99982), ('an', 0.99981), ('up', 0.99980)]
            sims_words = wv.similar_by_word(seedidx, topn=topn)
            #Convert words to index and store them
            similars_candidate_idxs.extend([dictionary[sim[0]] for sim in sims_words])
        similars_candidate_idxs = set(similars_candidate_idxs)
        
        for idx in similars_candidate_idxs:
            score = wv.n_similarity([idx], seedidxs)
            simidx_scores.append((idx, score))
        simidxs = [w[0] for w in sorted(simidx_scores, key=lambda k:k[1], reverse=True)]

        simwords = [str(wv.index_to_key[idx]) for idx in simidxs][:topn]

        resultwords = []
        resultwords.extend(seedwords)
        resultwords.extend(simwords)
        
        resultdict[seed_name] = resultwords
        
        output_dir = Path('output')
        output_dir.mkdir(exist_ok=True)
        candidate_txt_file = output_dir / f'{seed_name}.txt'
            
        with open(candidate_txt_file, 'w', encoding='utf-8') as f:
            for word in resultwords:
                f.write(word+'\n')

        print(f'Finish! {seed_name} candidates saved to output/{seed_name}.txt')



######################################################################################   
        

from gensim.models import FastText

def load_w2v(w2v_path):
    """
    读取word2vec模型文件; 支持.bin、 .txt、 .vec格式。

    Args:
        wv_path (str): word2vec模型文件路径

    Returns: gensim.models.keyedvectors.KeyedVectors
    """
    if w2v_path.endswith('.bin'):
        binary = True
        if '-FastText.' in w2v_path:
            model = FastText.load(w2v_path)
            wv = model.wv
        else:
            wv = KeyedVectors.load_word2vec_format(w2v_path, binary=binary)
            
    else:
        wv = KeyedVectors.load_word2vec_format(w2v_path, binary=False)
       
    
    print(f'Loading {w2v_path}...')
    return wv




######################################################################################   
        

def glove2word2vec(glove_file, word2vec_file):
    """
    将glove模型转换为word2vec模型。
    Args:
        glove_file (str): glove模型.txt文件路径
        word2vec_file (str): word2vec模型.txt文件路径
        
    Returns: 
        gensim.models.keyedvectors.KeyedVectors
    """
    # 使用 glove2word2vec 转换格式
    print('Converting GloVe model to Word2Vec format...')
    glove2wv(glove_file, word2vec_file)
    print('Finish! The word2vec model has been saved to {}.'.format(word2vec_file))
    glove_model = KeyedVectors.load_word2vec_format(word2vec_file, binary=False)
    return glove_model




                  
def get_total_memory():
    """获取系统RAM总内存（MB）"""
    return psutil.virtual_memory().total / (1024 * 1024)         



def get_available_memory():
    """
    获取系统剩余可用内存（MB）
    :return: 剩余可用内存（MB）
    """
    return psutil.virtual_memory().available / (1024 * 1024)



def calculate_actual_vocab_size(sentences):
    """
    统计语料库中的实际词汇表大小（唯一词的数量）
    :param sentences: 语料库的句子迭代器
    :return: 实际词汇表大小
    """
    vocab_set = set()
    for sentence in sentences:
        vocab_set.update(sentence)
    return len(vocab_set)




def estimate_word2vec_memory_usage(
    max_vocab_size, 
    vector_size, 
    workers=1, 
    avg_word_length=9, 
    dict_overhead_per_entry=280,
    thread_scaling_factor=0.5,
    thread_fixed_overhead=500
):
    """
    估算词汇表及其相关数据结构的内存占用（MB)，并考虑多线程的影响
    :param max_vocab_size: 最大词汇表大小
    :param vector_size: 向量维度
    :param workers: 线程数
    :param avg_word_length: 单词的平均长度（以字节为单位，默认9字节）
    :param dict_overhead_per_entry: 每个字典条目的内存开销（默认280字节）
    :param thread_scaling_factor: 每个线程占用的词汇表向量内存比例（默认0.5）
    :param thread_fixed_overhead: 每个线程的固定内存开销（默认500MB）
    :return: 内存占用（MB）
    """
    # 计算词汇表向量的内存占用
    vocab_vector_memory = max_vocab_size * vector_size * 4 / (1024 * 1024)  # 单位：MB

    # 计算辅助数据结构的内存开销
    other_overhead_memory = (
        (avg_word_length * max_vocab_size) + 
        (dict_overhead_per_entry * max_vocab_size)
    ) / (1024 * 1024)  # 单位：MB

    # 计算单个线程的内存开销
    thread_memory_usage = (
        vocab_vector_memory * thread_scaling_factor +  # 按比例占用词汇表向量内存
        thread_fixed_overhead  # 固定开销
    )

    # 计算多线程的总内存开销
    thread_overhead_memory = workers * thread_memory_usage

    # 总内存占用估算
    total_memory_used = vocab_vector_memory + other_overhead_memory + thread_overhead_memory
    return total_memory_used





def recommend_word2vec_params(
    actual_vocab_size, 
    vector_size, 
    avg_word_length=9, 
    dict_overhead_per_entry=280,
    safety_margin_ratio=0.2  # 安全冗余内存比例，默认为20%
):
    """
    根据系统剩余可用内存动态调整 max_vocab_size 和 workers
    :param actual_vocab_size: 实际词汇表大小（唯一词的数量）
    :param vector_size: 向量维度
    :param avg_word_length: 单词的平均长度（以字节为单位，默认9字节）
    :param dict_overhead_per_entry: 每个字典条目的内存开销（默认280字节）
    :param safety_margin_ratio: 安全冗余内存的比例（默认10%）
    :return: 调整后的最大词汇表大小和线程数
    """
    total_memory = get_total_memory()  # 系统总内存（MB）
    safety_margin = total_memory * safety_margin_ratio  # 动态计算安全边际
    
    available_memory = get_available_memory()  # 剩余可用内存（MB）

    # 初始设置 max_vocab_size 和 workers
    current_max_vocab_size = actual_vocab_size
    workers = multiprocessing.cpu_count()  # 初始使用最大线程数

    # 动态计算阈值
    vocab_per_worker_threshold = actual_vocab_size // 10  # 每个线程处理的词汇量阈值

    # 估算当前内存占用
    memory_usage = estimate_word2vec_memory_usage(
        current_max_vocab_size, 
        vector_size, 
        workers, 
        avg_word_length, 
        dict_overhead_per_entry
    )

    # 如果内存占用超出限制，则逐步减少 max_vocab_size 或 workers
    while memory_usage > available_memory - safety_margin and (current_max_vocab_size > 0 or workers > 1):
        if current_max_vocab_size >= workers * vocab_per_worker_threshold:  # 先削减 max_vocab_size
            reduction_step = max(1000, current_max_vocab_size // 10)  # 动态调整步长
            current_max_vocab_size -= reduction_step
            current_max_vocab_size = max(current_max_vocab_size, 0)  # 确保不小于0
            print(f"Reducing max_vocab_size to {current_max_vocab_size} due to memory constraints.")
        else:  # 如果 max_vocab_size 已经较小，则削减 workers
            workers -= 1
            print(f"Reducing workers to {workers} due to memory constraints.")

        # 重新估算内存占用
        memory_usage = estimate_word2vec_memory_usage(
            current_max_vocab_size, 
            vector_size, 
            workers, 
            avg_word_length, 
            dict_overhead_per_entry
        )

    if current_max_vocab_size == 0 and workers == 1:
        raise ValueError("Cannot reduce max_vocab_size or workers further. Training aborted.")
    
    print(f'Estimated memory usage: {memory_usage//1024} GB')
    print(f"Recommend max_vocab_size: {current_max_vocab_size} ")
    print(f"Recommend max_worker: {workers}")
    
    return current_max_vocab_size, workers




def estimate_glove_memory_usage(
    vocab_size, 
    vector_size, 
    workers=1, 
    cooccurrence_sparsity=0.99,  # 共现矩阵稀疏性，默认90%
    per_worker_overhead=100,    # 每个线程的固定内存开销（默认300MB）
):
    """
    估算 GloVe 训练的内存占用
    :param vocab_size: 词汇表大小
    :param vector_size: 向量维度
    :param workers: 线程数
    :param cooccurrence_sparsity: 共现矩阵稀疏性比例（默认90%）
    :param per_worker_overhead: 每个线程的固定内存开销（默认500MB）
    :param safety_margin_ratio: 安全冗余内存比例（默认10%）
    :return: 内存占用（MB）
    """
    # 词汇表向量的内存占用
    vocab_vector_memory = vocab_size * vector_size * 4 / (1024 * 1024)  # 单位：MB

    # 共现矩阵的内存占用（稀疏矩阵）
    cooccurrence_matrix_memory = vocab_size * vocab_size * (1 - cooccurrence_sparsity) * 4 / (1024 * 1024)  # 单位：MB

    # 辅助数据结构的内存开销（如字典、缓存等）
    auxiliary_memory = vocab_size * 50 / (1024 * 1024)  # 假设每个词汇条目占用50字节

    # 多线程的总内存开销
    thread_overhead_memory = workers * per_worker_overhead  # 单位：MB

    # 总内存占用估算
    total_memory_used = vocab_vector_memory + cooccurrence_matrix_memory + auxiliary_memory + thread_overhead_memory
    return total_memory_used


def recommend_glove_params(
    actual_vocab_size, 
    vector_size, 
    safety_margin_ratio=0.1,
    max_workers=None,
    min_workers=1         # 最小线程数（默认为1）
):
    """
    设置 GloVe 训练的最佳 workers 和预计调用的内存
    :param vocab_size: 词汇表大小
    :param vector_size: 向量维度
    :param safety_margin_ratio: 安全冗余内存比例（默认10%）
    :param max_workers: 最大线程数（默认为 CPU 核心数）
    :param min_workers: 最小线程数（默认为1）
    :return: 最佳 workers 数和预计调用的内存（MB）
    """
    # 获取系统总内存和当前可用内存
    total_memory = get_total_memory()  # 系统总内存（MB）
    available_memory = get_available_memory()  # 剩余可用内存（MB）

    # 动态计算安全边际
    safety_margin = total_memory * safety_margin_ratio

    # 初始设置最大线程数
    if max_workers is None:
        max_workers = multiprocessing.cpu_count()

    # 初始设置 workers 和内存估算
    best_workers = max_workers
    estimated_memory = estimate_glove_memory_usage(
        vocab_size=actual_vocab_size,
        vector_size=vector_size,
        workers=best_workers,
        safety_margin_ratio=safety_margin_ratio
    )

    # 如果内存占用超出限制，则逐步减少 workers
    while estimated_memory > available_memory - safety_margin and best_workers > min_workers:
        best_workers -= 1
        print(f"Reducing workers to {best_workers} due to memory constraints.")
        
        # 重新估算内存占用
        estimated_memory = estimate_glove_memory_usage(
            vocab_size=actual_vocab_size,
            vector_size=vector_size,
            workers=best_workers,
            safety_margin_ratio=safety_margin_ratio
        )

    # 如果 workers 已经无法再减少，则抛出警告
    if best_workers == min_workers and estimated_memory > available_memory - safety_margin:
        raise ValueError("Cannot reduce workers further. Training may exceed available memory.")

    
    now_available_memory = (available_memory - estimated_memory - safety_margin)//1024
    # 返回结果前进行训练速度评估
    print(f'Estimated memory usage: {estimated_memory//1024} GB')
    print(f"Recommend max_memory: {now_available_memory} GB")
    print(f"Recommend max_workers: {best_workers} ")
    return best_workers, now_available_memory


