import re
import jieba
from collections import Counter
import numpy as np
import pandas as pd
from .io import read_yaml_dict
from nltk.tokenize import word_tokenize
import warnings
import string
import networkx as nx
from distinctiveness.dc import distinctiveness



STOPWORDS_zh = read_yaml_dict(yfile='enzh_common_StopWords.yaml')['Dictionary']['chinese']
STOPWORDS_en = read_yaml_dict(yfile='enzh_common_StopWords.yaml')['Dictionary']['english']
zh_ADV_words = read_yaml_dict(yfile='enzh_common_AdvConj.yaml')['Dictionary']['zh_adv']
zh_CONJ_words = read_yaml_dict(yfile='enzh_common_AdvConj.yaml')['Dictionary']['zh_conj']



def zh_split_sentences(text):
    """
    Segment the chinese text into sentences
    
    Args:
        text (str): text to be segmented
        
    Returns:
        list of sentences
    """
    #split the chinese text into sentences
    # 1. 以句号分句
    text = re.sub('([。！；？;\?])([^”’])', "[[end]]", text)  # 单字符断句符
    text = re.sub('([。！？\?][”’])([^，。！？\?])', "[[end]]", text)
    text = re.sub('\s', '', text)
    # 如果双引号前有终止符，那么双引号才是句子的终点，把分句符\n放到双引号后，注意前面的几句都小心保留了双引号
    return text.split("[[end]]")


def en_split_sentences(text):
    # 定义分句的正则表达式
    pattern = r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!)\s'
    # 根据正则表达式分句
    sentences = re.split(pattern, text)
    # 如果最后一个句子没有结束符，则加上一个空格和句号作为结束符
    if not sentences[-1].endswith((".", "!", "?")):
        sentences[-1] += "."
    # 去掉句子中的空格
    sentences = [sentence.strip() for sentence in sentences]
    # 去掉空句子
    sentences = list(filter(None, sentences))
    return sentences

def cn_seg_sent(text):
    #split the chinese text into sentences
    text = re.sub('([。！；？;\?])([^”’])', "[[end]]", text)  # 单字符断句符
    text = re.sub('([。！？\?][”’])([^，。！？\?])', "[[end]]", text)
    text = re.sub('\s', '', text)
    # 如果双引号前有终止符，那么双引号才是句子的终点，把分句符\n放到双引号后，注意前面的几句都小心保留了双引号
    return text.split("[[end]]")



def term_freq(text, lang='chinese', return_df=False):
    """
    Calculates the word frequency

    :param language: "chinese" or "english"; default is "chinese"
    Args:
        text (str):text string
        lang (str, optional):setting the lang, only support chinese and english. Defaults to 'chinese'.
        return_df (bool, optional):return a dataframe or not. Defaults to False.

    Returns:
        _type_: _description_
    """

    # remove punctuation
    if lang=='chinese':
        #text = ''.join(re.findall('[\u4e00-\u9fa5]+', text))
        words = list(jieba.cut(text))
        words = [w for w in words if w not in STOPWORDS_zh]
    else:
        words = text.lower().split(" ")
        words = [w for w in words if w not in STOPWORDS_en]
        
    if return_df:
        return pd.DataFrame(Counter(words).items(), columns=['word', 'freq'])
    else:
        return Counter(words)




def readability(text, zh_advconj=None, lang='chinese'):
    """
    text readability, the larger the indicator, the higher the complexity of the article and the worse the readability.
    :param text: text string
    :param zh_advconj Chinese conjunctions and adverbs, receive list data type. By default, the built-in dictionary of cntext is used
    :param language: "chinese" or "english"; default is "chinese"
    ------------
    【English readability】english_readability = 4.71 x (characters/words) + 0.5 x (words/sentences) - 21.43；
    【Chinese readability】  Refer 【徐巍,姚振晔,陈冬华.中文年报可读性：衡量与检验[J].会计研究,2021(03):28-44.】
                 readability1  ---每个分句中的平均字数
                 readability2  ---每个句子中副词和连词所占的比例
                 readability3  ---参考Fog Index， readability3=(readability1+readability2)×0.5
                 以上三个指标越大，都说明文本的复杂程度越高，可读性越差。

    """
    if lang=='english':
        text = text.lower()
        #将浮点数、整数替换为num
        text = re.sub('\d+\.\d+|\.\d+', 'num', text)
        num_of_characters = len(text)
        #英文分词
        rgx = re.compile("(?:(?:[^a-zA-Z]+')|(?:'[^a-zA-Z]+))|(?:[^a-zA-Z']+)")
        num_of_words = len(re.split(rgx, text))
        #分句
        num_of_sentences = len(re.split('(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', text))
        ari = (
                4.71 * (num_of_characters / num_of_words)
                + 0.5 * (num_of_words / num_of_sentences)
                - 21.43
        )
        return {"readability": ari}
    if lang=='chinese':
        if zh_advconj:
            adv_conj_words = zh_advconj
        else:
            adv_conj_words = set(zh_ADV_words + zh_CONJ_words)
        zi_num_per_sent = []
        adv_conj_num_per_sent = []
        text = re.sub('\d+\.\d+|\.\d+', 'num', text)
        #【分句】
        sentences = cn_seg_sent(text)
        for sent in sentences:
            adv_conj_num = 0
            zi_num_per_sent.append(len(sent))
            words = list(jieba.cut(sent))
            for w in words:
                if w in adv_conj_words:
                    adv_conj_num+=1
            adv_conj_num_per_sent.append(adv_conj_num)
        readability1 = np.mean(zi_num_per_sent)
        readability2 = np.mean(adv_conj_num_per_sent)
        readability3 = (readability1+readability2)*0.5
        return {'readability1': readability1,
                'readability2': readability2,
                'readability3': readability3}





def sentiment(text, diction, lang='chinese', return_df=False):
    """
    Calculates the sentiment of each sentiment category words in text;
    the complex influence of intensity adverbs and negative words on emotion is not considered,
    
    Examples about diction parameter:
    
        diction = {'category1':  'category1 emotion word list',
                  'category2':  'category2 emotion word list',
                  'category3':  'category3 emotion word list',
                   ...
                }
    
    
    Args:
        text (str):  text string
        diction (dict): sentiment dictionary
        lang (str, optional): setting the lang, only support chinese and english. Defaults to 'chinese'.
        return_df (bool, optional): return a dataframe or not. Defaults to False.

    Returns:
        dict contains category and it's score
    """
    
     
    result_dict = dict()
    senti_categorys = diction.keys()

    stopword_num = 0
    for senti_category in senti_categorys:
        result_dict[senti_category+'_num'] = 0

    #sentence_num = len(re.split('[。！!？\?;；]+', text))-1
 
    if lang=='chinese':
        # using add_word to add chinese word in jieba
        for senti_category in senti_categorys:
            senti_category_words = diction[senti_category]
            for w in senti_category_words:
                try:
                    jieba.add_word(w)
                except:
                    pass


        sentence_num = len(zh_split_sentences(text))
        words = list(jieba.cut(text))
        word_num = len(words)
        for word in words:
            if word in STOPWORDS_zh:
                stopword_num+=1
            for senti_category in senti_categorys:
                if word in diction[senti_category]:
                    result_dict[senti_category+'_num'] +=  1

    else:
        sentence_num = len(re.split('(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', text.lower()))
        rgx = re.compile("(?:(?:[^a-zA-Z]+')|(?:'[^a-zA-Z]+))|(?:[^a-zA-Z']+)")
        words = re.split(rgx, text)
        word_num = len(words)
        for word in words:
            if word in STOPWORDS_en:
                stopword_num+=1
            for senti_category in senti_categorys:
                if word in diction[senti_category]:
                    result_dict[senti_category+'_num'] +=  1

    result_dict['stopword_num'] = stopword_num
    result_dict['word_num'] = word_num
    result_dict['sentence_num'] = sentence_num
    if return_df:
        return pd.DataFrame(result_dict, index=[0])
    return result_dict


    




def sentiment_by_valence(text, diction, lang='chinese', mean=False, return_df=False):
    """
    Calculate the occurrences of each sentiment category words in text;
    the complex influence of intensity adverbs and negative words on emotion is not considered.
    
    Args:
        text (str): text sring
        diction (dict): sentiment dictionary dataframe with valence.
        lang (str, optional):setting the lang, only support chinese and english. Defaults to 'chinese'.
        mean (boolean, optional): Whether calculate the average emotional information based on the number of words. Defaults to False.
        return_df (bool, optional): return a dataframe or not. Defaults to False.

    Returns:
        dict contains category and it's score
    """

    result = dict()
    result['text'] = text
    attrs = pd.DataFrame(diction).index
    for attr in attrs:
        result[attr] = 0
    

    if lang == 'chinese':
        words = list(jieba.cut(text))
        for word in words:
            if diction.get(word):
                for attr in attrs:
                    result[attr] = result[attr] + diction.get(word)[attr]


    else:
        text = text.lower()
        #rgx = re.compile("(?:(?:[^a-zA-Z]+')|(?:'[^a-zA-Z]+))|(?:[^a-zA-Z']+)")
        #words = re.split(rgx, text)
        try:
            words = word_tokenize(text)
        except:
            #print('你的电脑nltk没配置好，请观看视频https://www.bilibili.com/video/BV14A411i7DB')
            rgx = re.compile("(?:(?:[^a-zA-Z]+')|(?:'[^a-zA-Z]+))|(?:[^a-zA-Z']+)")
            words = re.split(rgx, text)

        for word in words:
            if diction.get(word):
                for attr in attrs:
                    result[attr] = result[attr] + diction.get(word)[attr]
      
    result['word_num'] = len(words)
    
    if mean==True:
        for attr in attrs:
            result[attr] = round(result[attr]/len(words), 3)
            
    if return_df:
        return pd.DataFrame(result, index=[0])
    return result 



def word_in_context(text, keywords, window=3, lang='chinese'):
    """
    Given text and keywords, the task is to find the text where the keyword appears
    Args:
        text (str): input document, string format
        keywords (list): keywords
        window (int): return the text where the keyword appears, default is 3, meaning return 3 word.
        lang (str, optional): setting the lang, only support chinese and english. Defaults to 'chinese'.

    Returns:
        list contains multiple dictionaries, where each dictionary contains the sentence, keyword, and the sentence where the keyword appears
    """
    if lang=='chinese':
        words = jieba.lcut(text.lower())
    else:
        try:
            words = word_tokenize(text.lower())
        except:
            warnings.warn("你应该安装nltk和对应的nltk_data, 请看B站https://www.bilibili.com/video/BV14A411i7DB")
            words = text.lower().split(' ')
            

    keywords = [w.lower() for w in keywords]
    kw_idxss = [[i for i, x in enumerate(words) if x == keyword] for keyword in keywords]
    rows = []
    for keyword, kw_idxs in zip(keywords, kw_idxss):
        for idx in kw_idxs:
            half = int((window-1)/2)
            start = max(0, idx - half)
            end = min(len(words), idx + half + 1)
            row = {'keyword': keyword, 
                   'context': ''.join(words[start: end]) if lang=='chinese' else ' '.join(words[start: end])
                      }
            rows.append(row)
    df = pd.DataFrame(rows)
    return df





def semantic_brand_score(text, brands, lang='chinese', co_range=7, link_filter=2):
    """
    The Semantic Brand Score (SBS) is a novel metric designed to assess the importance of one or more brands, in different contexts and whenever it is possible to analyze textual data, even big data. 
    
    Colladon, Andrea Fronzetti. "The semantic brand score." *Journal of Business Research* 88 (2018): 150-160.
    
    Args:
        text (string): string data to analysis
        brands (list): entitiy(person/company etc) list 
        lang (str, optional): Defaults to 'chinese'.
        co_range (int, optional): co-occurrence range. Defaults to 7.
        link_filter (int, optional): Remove links which represent negligible co-occurrences, for example those of link_filter=2. Defaults to 2.

    Returns:
        dataframe: _description_
    """
    #保证jieba能识别brands词。
    [jieba.add_word(w) for w in brands]


    regex = re.compile('[%s]' % re.escape(string.punctuation))
    if lang=='chinese':
        words = jieba.lcut(regex.sub('', text))
        words = [w for w in words if w not in STOPWORDS_zh]
    else:
        words = regex.sub(' ', text.lower()).split(' ')
        words = [w for w in words if w not in STOPWORDS_en]

        
    docs = [words]
    #Create a dictionary with frequency counts for each word
    countPR = Counter()
    for doc in docs:
        countPR.update(Counter(doc))
        
    #Calculate average score and standard deviation
    avgPR = np.mean(list(countPR.values()))
    stdPR = np.std(list(countPR.values()))

    PREVALENCE = {}
    for brand in brands:
        PREVALENCE[brand] = (countPR.get(brand, 0) - avgPR) / stdPR
        
        
        
    #Create an undirected Network Graph
    G = nx.Graph()

    #Each word is a network node
    nodes = set([word for doc in docs 
                for word in doc])
    G.add_nodes_from(nodes)

    #Add links based on co-occurrences
    for doc in docs:
        w_list = []
        length= len(doc)
        for k, w in enumerate(doc):
            #Define range, based on document length
            if (k+co_range) >= length:
                superior = length
            else:
                superior = k+co_range+1
            #Create the list of co-occurring words
            if k < length-1:
                for i in range(k+1,superior):
                    linked_word = doc[i].split()
                    w_list = w_list + linked_word
            #If the list is not empty, create the network links
            if w_list:    
                for p in w_list:
                    if G.has_edge(w,p):
                        G[w][p]['weight'] += 1
                    else:
                        G.add_edge(w, p, weight=1)
            w_list = []

    #Remove negligible co-occurrences based on a filter
    #Create a new Graph which has only links above
    #the minimum co-occurrence threshold
    G_filtered = nx.Graph() 
    G_filtered.add_nodes_from(G)
    for u,v,data in G.edges(data=True):
        if data['weight'] >= link_filter:
            G_filtered.add_edge(u, v, weight=data['weight'])

    #Optional removal of isolates
    isolates = set(nx.isolates(G_filtered))
    isolates -= set(brands)
    G_filtered.remove_nodes_from(isolates)
    
    
    
    #DIVERSITY
    #Calculate Distinctiveness Centrality
    DC = distinctiveness(G_filtered, normalize = False, alpha = 1)
    DIVERSITY_sequence=DC["D2"]

    #Calculate average score and standard deviation
    avgDI = np.mean(list(DIVERSITY_sequence.values()))
    stdDI = np.std(list(DIVERSITY_sequence.values()))
    #Calculate standardized Diversity for each brand
    DIVERSITY = {}
    for brand in brands:
        DIVERSITY[brand] = (DIVERSITY_sequence.get(brand, 0) - avgDI) / stdDI
        
        
    #Define inverse weights 
    for u,v,data in G_filtered.edges(data=True):
        if 'weight' in data and data['weight'] != 0:
            data['inverse'] = 1/data['weight']
        else:
            data['inverse'] = 1   

    #CONNECTIVITY
    CONNECTIVITY_sequence=nx.betweenness_centrality(G_filtered, normalized=False, weight ='inverse')
    #Calculate average score and standard deviation
    avgCO = np.mean(list(CONNECTIVITY_sequence.values()))
    stdCO = np.std(list(CONNECTIVITY_sequence.values()))
    #Calculate standardized Prevalence for each brand
    CONNECTIVITY = {}
    for brand in brands:
        CONNECTIVITY[brand] = (CONNECTIVITY_sequence.get(brand, 0) - avgCO) / stdCO
        
        
    #Obtain the Semantic Brand Score of each brand
    SBS = {}
    for brand in brands:
        SBS[brand] = PREVALENCE[brand] + DIVERSITY[brand] + CONNECTIVITY[brand]
        
    PREVALENCE_df = pd.DataFrame.from_dict(PREVALENCE, orient="index", columns = ["PREVALENCE"])
    DIVERSITY_df = pd.DataFrame.from_dict(DIVERSITY, orient="index", columns = ["DIVERSITY"])
    CONNECTIVITY_df = pd.DataFrame.from_dict(CONNECTIVITY, orient="index", columns = ["CONNECTIVITY"])
    SBS_df_ = pd.DataFrame.from_dict(SBS, orient="index", columns = ["SBS"])
    SBS_df = pd.concat([ PREVALENCE_df, DIVERSITY_df, CONNECTIVITY_df, SBS_df_ ], axis=1, sort=False)
    return SBS_df