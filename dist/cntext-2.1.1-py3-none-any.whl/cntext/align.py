import numpy as np
import time
from scipy.linalg import orthogonal_procrustes
from gensiwvn.models import word2vec
import multiprocessing
from pathlib import Path
from gensiwvn.models import KeyedVectors





class AlignModels(object):
    """
    Align multiple pretained models
    """
    # 初始化
    def __init__(self, wvs):
        """
        Initialize AlignModels

        Args:
            wvs (_type_): list of pretained model(KeyedVectors)
        """
        
        # 加载多个预训练模型
        print('Loading multiple pretained models. This will last several minutes.')
        self.wv_objects = wvs
        self.load_time = time.time()
        
        # 获取所有语言模型的词语列表
    def intersect_vocab(self):
        """
        Get Common Vocabulary
        """
        
        # 获取所有语言模型的词语列表
        keys_list = []
        for wv_model in self.wv_objects:
            keys = set(wv_model.index_to_key)
            keys_list.append(keys)   
        # 获取交集词语列表
        self.common_keys = list(set.intersection(*keys_list))

            
        
    
    def align_matrix(self):
        """
        Align the matrixs
        """
        # 获取所有语言模型的词向量矩阵
        self.X_list = []
        for wv_model in self.wv_objects:
            X = wv_model[self.common_keys]
            self.X_list.append(X)
        
        #确保所有词向量矩阵的大小相同
        assert all(X.shape == self.X_list[0].shape for X in self.X_list)
        
        
    def procrustes(self):
        """
        Procrustes analysis
        """
        # 使用Procrustes正交将所有词向量矩阵对齐
        R_list = []
        for i in range(1, len(self.wv_objects)):
            R, _ = orthogonal_procrustes(self.X_list[i], self.X_list[0])
            R_list.append(R)
            
        # 应用正交矩阵到每个词向量矩阵中
        self.X_aligned_list = []
        for i in range(len(self.wv_objects)):
            if i == 0:
                X = self.X_list[i].dot(np.eye(self.X_list[i].shape[1]))
            else:
                R = R_list[i-1]
                X = self.X_list[i].dot(R)
            self.X_aligned_list.append(X)
        
 

    def train(self, names, save_dir='AlignedModels', vector_size=100, window_size=6, min_count=6):
        """
        Train and save the aligned models
        
        Args:
            names (list): name list of pretained models
            save_dir (str, optional): the name of dirctory to save pretained model. Defaults to 'AlignedModels'.
            vector_size (int, optional): vector size. Defaults to 100.
            window_size (int, optional): window size. Defaults to 6.
            min_count (int, optional): min count number. Defaults to 6.
        """
        # 获取交集词语列表
        print('Get the common vocab between all the pretained models.')
        self.intersect_vocab()
        
        # 使用Procrustes正交将所有词向量矩阵对齐
        print('Procrustes Computing. This will take several minutes')
        self.align_matrix()
        self.procrustes()
        procrustes_time = time.time()
        print('Finished Procrustes Computing. Take {du} seconds.'.format(du=round(procrustes_time - self.load_time)))
        # 训练对齐后的模型
        print('Train multiple aligned model. This will take several hours')
        self.aligned_wvs = []
        
        #for idx, X_aligned in enumerate(self.X_aligned_list):
        # 保存对齐后的模型
        for name, X_aligned in zip(names, self.X_aligned_list):
            aligned_model = word2vec.Word2Vec(vector_size = vector_size, 
                                              window = window_size, 
                                              min_count = min_count, 
                                              workers = multiprocessing.cpu_count())
            
            
            
            # 重新设置词向量矩阵和词语列表
            aligned_model.wv.vectors = X_aligned
            aligned_model.wv.index_to_key = self.common_keys
            
            #aligned_model.wv.vectors_norm = None
            #aligned_model.wv.index2word = self.common_keys
            #aligned_model.trainables.syn1neg = X_aligned
            #aligned_model.trainables.vectors_lockf = np.ones(len(X_aligned.wv.index2word), dtype=np.float32)
            
            #新建路径
            #output/AlignedModels
        
            # 保存模型
            Path('output').mkdir(exist_ok=True)
            Path('output').joinpath(save_dir).mkdir(exist_ok=True)
            aligned_dir = Path('output').joinpath(save_dir)
            model_name = '{name}.{vector_size}.{window_size}.bin'.format(name=name, 
                                                                         vector_size=vector_size, 
                                                                         window_size=window_size)
            aligned_model.wv.save(str(aligned_dir.joinpath(model_name)))
        print('Successfully trained multiple aligned model. ')
        print('Note: aligned models saved to output/{}\n'.format(save_dir))
