from openai import OpenAI
from pydantic import BaseModel, create_model
from typing import List
import os
import instructor
import requests
import ollama
import pandas as pd


def text_analysis_by_llm(text,
                         prompt="根据评论内容，返回文本的情感类别label(label的值为pos、neg)和情感分值score(score取值范围-1~1)",
                         base_url='',
                         api_key='',
                         model_name="qwen2.5:3b",
                         temperature=0,
                         output_format = {'label': str, 'score': float},
                         max_retries=3,
                         return_df=False):
    """
    使用本地Ollama安装的大模型(或在线大模型api服务)进行情感分析； 离线模式下，请先确保Ollama环境配置好，详细使用介绍可 https://textdata.cn/blog/2024-06-14-how-to-download-large-language-model-with-ollama/ ；

    Args:
        text(str): 待分析的文本
        prompt (str, optional): 提示Prompt, 默认 prompt="根据评论内容，返回文本的情感类别(pos、neg)", 可判断文本pos或neg
        base_url(str, optional): 大模型API接口， 默认base_url=''， 默认使用的本地Ollama搭建服务的API接口；
        api_key(str, optional): 大模型API对应的KEY， 默认api_key='' 表示使用的本地Ollama搭建服务
        model_name(str, optional): 模型名；默认使用 model_name="qwen2.5:3b"
        temperature(float, optional): 控制模型输出结果的随机性，默认temperature=0；取值范围0到无穷, 常用的范围[0, 1]。虽然理论上可以设置大于 1 的值，但这样会导致输出过于随机，通常不推荐这样做。需要结合任务确定取值
            - 高准确性一致性任务，如情感分析、文本分类、事实性回答， 建议temperature=0
            - 高创造性和多样性任务， 如故事写作、头脑风暴等， 建议temperature=0.7
            - 实验性或探索性任务，较高的 `temperature` 值（如 1.0 以上，但一般不推荐超过 2.0）
        output_format(dict, optional): 设置分析结果的输出格式; 默认output_format = {'label': str, 'score': float},   输出结果为字典， 含字段类别字段label和数值字段score
        max_retries (int, optional): 最大失败次数， 默认max_retries=3
        return_df (bool, optional): 返回结果是否为dataframe， 默认False

    Returns:
        dict or DataFrame
    """
    if not base_url:
        base_url = 'http://127.0.0.1:11434/v1'
    if not api_key:
        api_key = 'NA'


    client = instructor.from_openai(
        OpenAI(
            base_url=base_url,
            api_key=api_key,  # required, but unused
        ),
        mode=instructor.Mode.JSON,
    )

    #根据prompt， 设置输出结果的格式，字段类型
    field_definitions = {}
    for field_name, field_type in output_format.items():
        if isinstance(field_type, str):
            field_type = eval(field_type)  # 将字符串类型的类型名转换为实际类型
        field_definitions[field_name] = (field_type, ...)


    resp = client.chat.completions.create(
        model = model_name,
        messages=[
            {"role": "system", "content": prompt}, #提示PROMP
            {"role": "user", "content": text} #评论文本
        ],
        response_model = create_model('OutputFormat', **field_definitions),
        max_retries = max_retries,
        temperature = temperature,

    )

    if return_df:
        return pd.DataFrame(resp.dict(), index=[0])
    
    return resp.model_dump()

def analysis_by_llm(text,
                    prompt="根据评论内容，返回文本的情感类别label(label的值为pos、neg)和情感分值score(score取值范围-1~1)",
                    base_url='',
                    api_key='',
                    model_name="qwen2.5:3b",
                    temperature=0,
                    output_format = {'label': str, 'score': float},
                    max_retries=3,
                    return_df=False):
    """
    使用本地Ollama安装的大模型(或在线大模型api服务)进行情感分析； 离线模式下，请先确保Ollama环境配置好，详细使用介绍可 https://textdata.cn/blog/2024-06-14-how-to-download-large-language-model-with-ollama/ ；

    Args:
        text(str): 待分析的文本
        prompt (str, optional): 提示Prompt, 默认 prompt="根据评论内容，返回文本的情感类别(pos、neg)", 可判断文本pos或neg
        base_url(str, optional): 大模型API接口， 默认base_url=''， 默认使用的本地Ollama搭建服务的API接口；
        api_key(str, optional): 大模型API对应的KEY， 默认api_key='' 表示使用的本地Ollama搭建服务
        model_name(str, optional): 模型名；默认使用 model_name="qwen2.5:3b"
        temperature(float, optional): 控制模型输出结果的随机性，默认temperature=0；取值范围0到无穷, 常用的范围[0, 1]。虽然理论上可以设置大于 1 的值，但这样会导致输出过于随机，通常不推荐这样做。需要结合任务确定取值
            - 高准确性一致性任务，如情感分析、文本分类、事实性回答， 建议temperature=0
            - 高创造性和多样性任务， 如故事写作、头脑风暴等， 建议temperature=0.7
            - 实验性或探索性任务，较高的 `temperature` 值（如 1.0 以上，但一般不推荐超过 2.0）
        output_format(dict, optional): 设置分析结果的输出格式; 默认output_format = {'label': str, 'score': float},   输出结果为字典， 含字段类别字段label和数值字段score
        max_retries (int, optional): 最大失败次数， 默认max_retries=3
        return_df (bool, optional): 返回结果是否为dataframe， 默认False

    Returns:
        dict or DataFrame
    """
    if not base_url:
        base_url = 'http://127.0.0.1:11434/v1'
    if not api_key:
        api_key = 'NA'


    client = instructor.from_openai(
        OpenAI(
            base_url=base_url,
            api_key=api_key,  # required, but unused
        ),
        mode=instructor.Mode.JSON,
    )

    #根据prompt， 设置输出结果的格式，字段类型
    field_definitions = {}
    for field_name, field_type in output_format.items():
        if isinstance(field_type, str):
            field_type = eval(field_type)  # 将字符串类型的类型名转换为实际类型
        field_definitions[field_name] = (field_type, ...)


    resp = client.chat.completions.create(
        model = model_name,
        messages=[
            {"role": "system", "content": prompt}, #提示PROMP
            {"role": "user", "content": text} #评论文本
        ],
        response_model = create_model('OutputFormat', **field_definitions),
        max_retries = max_retries,
        temperature = temperature

    )

    if return_df:
        return pd.DataFrame(resp.dict(), index=[0])
    
    return resp.model_dump()