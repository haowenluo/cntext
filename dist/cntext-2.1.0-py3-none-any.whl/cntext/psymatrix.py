import numpy as np
import h5py
from pathlib import Path
import h5py


# 定义概念轴的正负词集合
CONCEPTS_PAIRS = {
    '时间': {
        'pos': ['未来', '将来', '之后', '明天', '后天', '将来的', '未来的', '将来时', '未来时'], 
        'neg': ['过去', '之前', '早先', '前天', '昨天', '旧时光', '曾经',  '旧日', '过去的', '早先的', '过去时', '早先时']
        },
    
    '空间': {
        'pos': ['远', '远离', '遥远', '外部', '异地', '异乡', '异国', '国外', '异域'],
        'neg': ['近', '附近', '近处', '内部', '本地', '本乡', '周围', '身边', '身旁', '身边的']
    },
    
    '人物': {
        'pos': ['主人公', '主角', '家人', '支持者', '亲人', '朋友', '伙伴', '同事', '同伴', '同胞', '同志', '同学'],
        'neg': ['敌人', '对手', '陌生人', '竞争者', '外人', '敌对者', '对抗者', '对立者', '对立面', '对手']
    },
    
    '行动(成长)': {
        'pos': ['努力', '奋斗', '决策', '行动', '坚持', '坚决', '前进', '进步', '发展', '进展', '进取'],
        'neg': ['放弃', '犹豫', '退缩', '退却', '退步', '停止', '停滞', '逃避', '后退', '倒']
    },
    
    '目标': {
        'pos': ['实现', '达成', '成功', '胜利', '达到', '突破', '取得', '优势'],
        'neg': ['失败', '丢失', '挫折', '挫败', '挑战', '困难', '不足']
    },
    
    '情感': {
        'pos': ['快乐', '满足', '喜悦', '兴奋', '愉快', '高兴', '爽', '喜欢', '爱', '激动'],
        'neg': ['悲', '哀', '哀伤', '哀怨', '哀叹', '哀', '叹', '怒', '怨', '恨', '厌', '悲伤', '失望', '痛苦', '难过', '伤心', '痛', '郁闷', '压抑', '沮丧', '丧']
    },
    
    '叙事视角':{
        'pos': ['我', '亲自', '亲眼所见', '我们', '你'],
        'neg': ['他', '他们', '客观', '第三人称', '第三方', '第三者', '他人']
    },
    
    '叙事节奏': {
        'pos': ['快速', '紧张', '急促', '冲突', '迅速', '跳跃', '高潮', '强烈', '转折', '矛盾', '压力', '刺激'],
        'neg': ['缓慢', '轻松', '平静', '和谐', '安宁', '优雅', '平淡', '平稳']
    },
    
    '主观客观': {
        'pos': ['主观', '觉得', '感觉', '想', '想象', '我猜', '猜测', '猜想'], 
        'neg': ['客观', '科学', '论证', '论据', '事实', '数据', '证据']
    },
    
    '因果逻辑': ['因为', '由于', '由此', '因此', '所以', '从而', '所以', '但是', '然而', '不过', '但', '可是', '但是', '不过'],
    
    '具体抽象': {
        'pos': ['具体', '细节'],
        'neg': ['逻辑', '形而上']
    },
    
    '动机':  ['需要', '想要', '希望', '渴望', '渴求', '欲望', '渴望', '渴求', '欲望', '渴望', '渴求'],
    
    '道德价值观': {
        'pos': ['真', '善', '正义', '公正', '正直', '正义', '平等', '和谐'],
        'neg': ['假', '恶', '邪恶', '不公', '不正', '不义', '暴力']
    },
}




def cosine_sim(a, b):
    dot_product = np.dot(a, b)
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    sim = dot_product / (norm_a * norm_b)
    return sim
        
        
class PsyMatrixCalculator:
    def __init__(self, wv, concepts=None):
        """
        PsyMatrixCalculator

        Args:
            wv (KeyedVectors): word2vec model
            concepts (dict): concepts dict, format just like, default using built-in CONCEPTS_PAIRS
            
            CONCEPTS_PAIRS = {
            '上-下': {
                'pos': ['上', '上方', '顶端', 'top', 'up', '上面', '上去', '高', '高处'],
                'neg': ['下', '底部', '底部', '下方', '下去', '下面', '低', '低下']},
                
            '前-后':  {
                'pos', ['前', '前方', '前面', '前进'],
                'neg': ['后', '后退', '尾巴', '后面', '后退']
                }
            
            }
        """
        self.wv = wv
        self.concepts = concepts
        self.gmatrix = None


    def GroupPsyMatrix(self):
        if self.concepts is None:
            self.concepts = CONCEPTS_PAIRS
        # 计算概念轴的向量
        m = self.wv.vector_size
        gaxis = {}
        for concept, words in self.concepts.items():
            pos_vecs = []
            for word in words["pos"]:
                if word in self.wv:
                    try:
                        pos_vecs.append(self.wv[word] / np.linalg.norm(self.wv[word]))
                    except:
                        pass
            neg_vecs = []
            for word in words["neg"]:
                if word in self.wv:
                    try:
                        neg_vecs.append(self.wv[word] / np.linalg.norm(self.wv[word]))
                    except:
                        pass
            pos_mean = np.mean(pos_vecs, axis=0) if len(pos_vecs) > 0 else np.zeros(m)
            neg_mean = np.mean(neg_vecs, axis=0) if len(neg_vecs) > 0 else np.zeros(m)
            gaxis[concept] = (pos_mean - neg_mean) / (len(pos_vecs) + len(neg_vecs))

        # 将所有概念轴的向量拼接成一个矩阵，即为群体心理表征矩阵
        self.gmatrix = np.vstack(list(gaxis.values()))
 

    def PersonPsyMatrix(self, words):
        """
        generate PersonPsyMatrix

        Args:
            words (list): words list

        Returns:
            _type_: PersonPsyMatrix, ndarray type
        """
        # ...（省略代码）
           # 查找词序列对应的词向量
        if self.gmatrix is None:
            self.GroupPsyMatrix()
        vecs = []
        for word in words:
            if word in self.wv:
                try:
                    vecs.append(self.wv[word])
                except:
                    pass
        z = len(vecs)
        if z == 0:
            return None

        # 计算每个概念轴的投影向量
        s, m = self.gmatrix.shape
        paxis = np.zeros((s, m))
        for j in range(s):
            proj_vecs = []
            for vec in vecs:
                proj = np.dot(vec, self.gmatrix[j]) / np.dot(self.gmatrix[j], self.gmatrix[j])
                proj_vecs.append(proj * self.gmatrix[j] / np.linalg.norm(self.gmatrix[j]))
            paxis[j] = np.mean(proj_vecs, axis=0) if len(proj_vecs) > 0 else np.zeros(m)


        # 将所有投影向量拼接成一个矩阵，即为个体的心理表征矩阵
        pmatrix = np.vstack(paxis)
        return pmatrix


    def weighted_PersonPsyMatrix(self, pmatrixs, lambda_val):
        """
        weighted_PersonPsyMatrix

        Args:
            pmatrixs (list): list of psymatrix
            lambda_val (float): memory lambda value
        """
        
        num_matrices = len(pmatrixs)
        weighted_numerators = np.zeros_like(pmatrixs[0])
        weighted_denominators = 0

        for t, pmatrix in enumerate(pmatrixs):
            weight = lambda_val ** (num_matrices - t - 1)
            weighted_numerators += weight * pmatrix
            weighted_denominators += weight

        weighted_pm = weighted_numerators / weighted_denominators
        return weighted_pm
    
    
    
    
    def save_to_hdf5(self, pmatrix, user_id, time_id, file, save_dir='output'):
        """
        save psymatrix ndarray data to hdf5
        Args:
            pmatrix (ndarray): personal psymatrix
            user_id (int, str): user id
            time_id (time_id): time id
            file (str): file name, default save to 「output」 dir
            save_dir (str): save dir, default is 「output」
            
        Returns:
            ndarray:  psymatrix
        """
        Path(save_dir).mkdir(exist_ok=True)
        filepath = Path(save_dir).joinpath(file)
        with h5py.File(filepath, "a") as hdf:
            user_group = hdf.require_group(str(user_id))
            user_group.create_dataset(str(time_id), data=pmatrix)
            

    def load_from_hdf5(self, file, user_id, time_id):
        """
        load psymatrix ndarray data from hdf5

        Args:
            file (str): hdf5 file name
            user_id (int, str): user id
            time_id (int, str): time id


        Returns:
            ndarray:  psymatrix
        """
        with h5py.File(file, "r") as hdf:
            user_group = hdf[str(user_id)]
            pmatrix = user_group[str(time_id)][()]
        return pmatrix
    
    
    def project_words_meaning(self, matrix, words):
        """
        get the words meaning of a give Psy

        Args:
            wv (KeyedVectors): _description_
            matrix (ndarray): PsyMatrix, such as GroupPsyMatrix or PersonPsyMatrix
            words (list): word list

        Returns:
            ndarray: the projection of words meaning
        """
        vecs = []
        for w in words:
            try:
                vecs.append(self.wv[w])
            except:
                pass
        if len(vecs) == 0:
            return np.zeros(matrix.shape[1])
        proj = np.dot(vecs, matrix.T) / np.linalg.norm(matrix, axis=1)
        if len(proj) == 1:
            return proj[0]
        else:
            return np.mean(proj, axis=0)
    
    
    def matrix_similarity(self, matrixs, return_vec=False):
        """
        calculate the similarity of a list of matrices

        Args:
            matrixs (list): a list of matrixs
            return_vec (bool, optional): whether to return the similarity of each axis, default False

        Returns:
            float: similarity
        """
        num_matrixs = len(matrixs)
        sims = []
        
        for i in range(num_matrixs - 1):
            assert matrixs[i].shape == matrixs[i+1].shape, "two matrices shape is not same!"
            num_axes = matrixs[i].shape[0]
            axis_sims = []
            
            for j in range(num_axes):
                axis_sim = cosine_sim(matrixs[i][j], matrixs[i+1][j])
                axis_sims.append(axis_sim)
            
            if return_vec:
                sims.append(axis_sims)
            else:
                avg_sim = np.mean(axis_sims)
                sims.append(avg_sim)
        
        return sims

    






def plot_semantic_difference(proj1, proj2, label1, label2, keyword, concepts = None, hbar=False):
    """
    plot the semantic difference of two objects(person、group)
    
    

    Args:
        proj1 (ndarray): the PsyMatrix of the object1
        proj2 (ndarray): the PsyMatrix of the object2
        label1 (str): the label of the object1
        label2 (str): the label of the object2
        keyword (str): the keyword you are interesting
        concepts (dict, optional): concepts dict, format just like, default using built-in CONCEPTS_PAIRS
        hbar (bool, optional): whether to use horizontal bar chart, default False
        
        CONCEPTS_PAIRS = {
            '上-下': {
                'pos': ['上', '上方', '顶端', 'top', 'up', '上面', '上去', '高', '高处'],
                'neg': ['下', '底部', '底部', '下方', '下去', '下面', '低', '低下']},
            '前-后':  {
                'pos', ['前', '前方', '前面', '前进'],
                'neg': ['后', '后退', '尾巴', '后面', '后退']
            },
            ...
            }
            
    Returns:
        _type_: matplotlib.pyplot.figure
    """
    if not concepts:
        concepts = CONCEPTS_PAIRS
    import matplotlib.pyplot as plt
    import matplotlib
    import platform
    import matplotlib_inline
    matplotlib_inline.backend_inline.set_matplotlib_formats('png', 'svg')
    import scienceplots
    plt.style.use(['science', 'no-latex', 'cjk-sc-font'])
    system = platform.system()  # 获取操作系统类型

    if system == 'Windows':
        font = {'family': 'SimHei'}
    elif system == 'Darwin':
        font = {'family': 'Arial Unicode MS'}
    else:
        # 如果是其他系统，可以使用系统默认字体
        font = {'family': 'sans-serif'}
    matplotlib.rc('font', **font)  # 设置全局字体
        
    if not hbar:

        # 将差异可视化
        fig, ax = plt.subplots(figsize=(12, 6))
        x = np.arange(len(concepts))
        ax.bar(x - 0.2, proj1, 0.35, label=label1, align='center')
        ax.bar(x + 0.15, proj2, 0.35, label=label2, align='center')

        # 添加刻度标签
        ax.set_xticks(x)
        labels = concepts.keys()

        bottom_labels = [la.split('-')[-1] for la in labels]
        top_labels = [la.split('-')[0] for la in labels]

        ax.set_xticklabels(bottom_labels, rotation=0, ha='right', fontsize=8)
        for i, tick in enumerate(top_labels):
            ax.axvline(i - 0.5, linestyle='--', color='lightgray', alpha=0.5)
            ax.text(i-0, + 0.97, tick, ha='center', transform=ax.get_xaxis_transform(), rotation=0, fontsize=8)


        # 设置轴标签和标题
        ax.set_ylabel('Difference')
        ax.set_xlabel('concept axis')
        ax.set_title('Difference between {label1} and {label2} about "{keyword}"'.format(keyword=keyword, label1=label1, label2=label2))
        ax.title.set_y(1.1)
        # 隐藏顶部边界线和图例
        ax.spines['top'].set_visible(False)
        ax.tick_params(axis='x', which='both', top=False)
        ax.legend(loc='upper right')

        plt.show()
        
    
    else:
        
        # 将差异可视化
        fig, ax = plt.subplots(figsize=(8, 8))
        y = np.arange(len(concepts))
        ax.barh(y + 0.18, proj1, 0.35, label=label1, align='center')
        ax.barh(y - 0.18, proj2, 0.35, label=label2, align='center')

        # 添加刻度标签
        ax.set_yticks(y)
        labels = concepts.keys()
        bottom_labels = [la.split('-')[-1] for la in labels]
        top_labels = [la.split('-')[0] for la in labels]
        ax.set_yticklabels(bottom_labels, rotation=0, ha='right')
        for i, tick in enumerate(top_labels):
            ax.axhline(i - 0, linestyle='--', color='lightgray', alpha=0.5)
            ax.text(10, i, tick, va='center')

        # 设置轴标签和标题
        ax.set_xlabel('Difference')
        ax.set_ylabel('concept axis')
        ax.set_title('Difference between {label1} and {label2} about "{keyword}"'.format(keyword=keyword, label1=label1, label2=label2))
        ax.title.set_position([0.5, 1.05])

        # 隐藏右侧边界线和图例
        ax.spines['right'].set_visible(True)
        ax.tick_params(axis='y', which='both', right=False)
        ax.legend(loc='lower right')

        plt.show()
