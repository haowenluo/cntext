from sklearn.feature_extraction.text import CountVectorizer
from gensim.models import word2vec
from collections import Counter
from collections import defaultdict
from pathlib import Path
from nltk.tokenize import word_tokenize
import jieba.posseg as pseg
from mittens import GloVe
from gensim.models.phrases import Phrases, ENGLISH_CONNECTOR_WORDS
from gensim.models.word2vec import LineSentence
import multiprocessing
import numpy as np
import math, time
import jieba
from .io import read_yaml_dict
import gensim
from collections import OrderedDict
import os
import pandas as pd
import gc


######################################################################################################################

class SoPmi:
    """
    Only support chinese now.
    """
    
    # 初始化
    def __init__(self, corpus_file, seed_file, lang='chinese'):
        """
        Init the SoPmi class
        
        Args:
            corpus_file (str): The path of the corpus file
            seed_file (str): the path of manually selected seed word file
            lang (str, optional): setting the lang, only support chinese and english. Defaults to 'chinese'.
        """
        self.corpus_file = corpus_file.replace('\\', '/')
        self.seed_file = seed_file.replace('\\', '/')
        self.lang=lang
        self.STOPWORDS_zh = read_yaml_dict(yfile='enzh_common_StopWords.yaml')['Dictionary']['chinese']
        self.STOPWORDS_en = read_yaml_dict(yfile='enzh_common_StopWords.yaml')['Dictionary']['english']
        



    def seg_corpus(self, corpus_file, seed_file):
        """
        Segment the corpus into list of mulptiple string.
        
        Args:
            corpus_file (str): file path of the corpus file
            seed_file (str): file path of manually selected seed word file

        Returns:
            return a list of mulptiple string.
        """
        #Add words to the jieba dictionary to ensure that the segmentation can't cut the seed emotional words
        if self.lang=='chinese':
            sentiment_words = [line.strip().split('\t')[0] for line in open(seed_file, encoding='utf-8')]
            for word in sentiment_words:
                jieba.add_word(word)

            seg_data = list()
            count = 0
            for line in open(corpus_file, encoding='utf-8'):
                line = line.strip()
                count += 1
                if line:
                    seg_data.append([word.word for word in pseg.cut(line) if word.flag[0] not in ['u','w','x','p','q','m']])
                else:
                    continue
        elif self.lang=='english':
            pass
        return seg_data




    def collect_cowords(self, seed_file, seg_data):
        """
        Calculate the co-words stats infomation of the seed word.
        
        Args:
            seed_file (str): the path of manually selected seed word file
            seg_data (list): list of string
            
        Returns:
            list: a list of co-words
        """
        def check_words(sent):
            if set(sentiment_words).intersection(set(sent)):
                return True
            else:
                return False

        cowords_list = list()
        window_size = 5
        count = 0
        sentiment_words = [line.strip().split('\t')[0] for line in open(seed_file, encoding='utf-8')]
        for sent in seg_data:
            count += 1
            if check_words(sent):
                for index, word in enumerate(sent):
                    if index < window_size:
                        left = sent[:index]
                    else:
                        left = sent[index - window_size: index]
                    if index + window_size > len(sent):
                        right = sent[index + 1:]
                    else:
                        right = sent[index: index + window_size + 1]
                    context = left + right + [word]
                    if check_words(context):
                        for index_pre in range(0, len(context)):
                            if check_words([context[index_pre]]):
                                for index_post in range(index_pre + 1, len(context)):
                                    cowords_list.append(context[index_pre] + '@' + context[index_post])
        return cowords_list


    def collect_candiwords(self, seg_data, cowords_list, seed_file):
        """
        Collect the candidate words of the seed word.

        Args:
            seg_data (list): list of string
            cowords_list (list): co-words list
            seed_file (str): the selected seed word file path
            
        Returns:
            dict: pmi_dict
        """
        def compute_mi(p1, p2, p12):
            '''Mutual information calculation function'''
            return math.log2(p12) - math.log2(p1) - math.log2(p2)
        '''统计词频'''
        def collect_worddict(seg_data):
            word_dict = dict()
            for line in seg_data:
                for word in line:
                    if word not in word_dict:
                        word_dict[word] = 1
                    else:
                        word_dict[word] += 1
            all = sum(word_dict.values())
            return word_dict, all
        '''统计词共现次数'''
        def collect_cowordsdict(cowords_list):
            co_dict = dict()
            candi_words = list()
            for co_words in cowords_list:
                candi_words.extend(co_words.split('@'))
                if co_words not in co_dict:
                    co_dict[co_words] = 1
                else:
                    co_dict[co_words] += 1
            return co_dict, candi_words
        
        
        '''收集种子情感词'''
        def collect_sentiwords(seed_file, word_dict):
            pos_words = set([line.strip().split('\t')[0] for line in open(seed_file, encoding='utf-8') if
                             line.strip().split('\t')[1] == 'pos']).intersection(set(word_dict.keys()))
            neg_words = set([line.strip().split('\t')[0] for line in open(seed_file, encoding='utf-8') if
                             line.strip().split('\t')[1] == 'neg']).intersection(set(word_dict.keys()))
            return pos_words, neg_words
         
        
        '''计算sopmi值'''
        def compute_sopmi(candi_words, pos_words, neg_words, word_dict, co_dict, all):
            pmi_dict = dict()
            for candi_word in set(candi_words):
                pos_sum = 0.0
                neg_sum = 0.0
                for pos_word in pos_words:
                    p1 = word_dict[pos_word] / all
                    p2 = word_dict[candi_word] / all
                    pair = pos_word + '@' + candi_word
                    if pair not in co_dict:
                        continue
                    p12 = co_dict[pair] / all
                    pos_sum += compute_mi(p1, p2, p12)

                for neg_word in neg_words:
                    p1 = word_dict[neg_word] / all
                    p2 = word_dict[candi_word] / all
                    pair = neg_word + '@' + candi_word
                    if pair not in co_dict:
                        continue
                    p12 = co_dict[pair] / all
                    neg_sum += compute_mi(p1, p2, p12)

                so_pmi = pos_sum - neg_sum
                pmi_dict[candi_word] = so_pmi
            return pmi_dict

        word_dict, all = collect_worddict(seg_data)
        co_dict, candi_words = collect_cowordsdict(cowords_list)
        pos_words, neg_words = collect_sentiwords(seed_file, word_dict)
        pmi_dict = compute_sopmi(candi_words, pos_words, neg_words, word_dict, co_dict, all)
        return pmi_dict


    def save_candiwords(self, pmi_dict, save_dir='SoPmi'):
        """
        Save the so-pmi result
        
        Args:
            pmi_dict(dict): pmi_dict
            save_dir(str): the save directory, default is 'SoPmi'
            
        returns:
            None
        """
        def get_tag(word):
            if word:
                return [item.flag for item in pseg.cut(word)][0]
            else:
                return 'x'
        pos_dict = dict()
        neg_dict = dict()
        Path('output').mkdir(exist_ok=True)
        Path('output').joinpath('SoPMI').mkdir(exist_ok=True)
        negfile= Path('output').joinpath(save_dir, 'neg.txt')
        posfile= Path('output').joinpath(save_dir, 'pos.txt')

        f_neg = open(negfile, 'w+', encoding='utf-8')
        f_pos = open(posfile, 'w+', encoding='utf-8')

        for word, word_score in pmi_dict.items():
            if word_score > 0:
                pos_dict[word] = word_score
            else:
                neg_dict[word] = abs(word_score)

        for word, pmi in sorted(pos_dict.items(), key=lambda asd:asd[1], reverse=True):
            f_pos.write(word+'\n')
        for word, pmi in sorted(neg_dict.items(), key=lambda asd:asd[1], reverse=True):
            f_neg.write(word+'\n')
        f_neg.close()
        f_pos.close()
        return



    def train(self, save_dir='SoPmi'):
        """
        Train the SoPmi model
        
        Args:
            save_dir(str): the save directory, default is 'SoPmi'
        """
        print('Step 1/4:...Preprocess   Corpus ...')
        start_time  = time.time()
        seg_data = self.seg_corpus(self.corpus_file, self.seed_file)
        
        print('Step 2/4:...Collect co-occurrency information ...')
        cowords_list = self.collect_cowords(self.seed_file, seg_data)
        
        print('Step 3/4:...Calculate   mutual information ...')
        pmi_dict = self.collect_candiwords(seg_data, cowords_list, self.seed_file)
        
        print('Step 4/4:...Save    candidate words ...')
        self.save_candiwords(pmi_dict, save_dir=save_dir)
        end_time = time.time()
        duration = end_time-start_time
        duration = round(duration, 2)
        print('Finish! used {0} s'.format(duration))








######################################################################################################################

def co_occurrence_matrix(documents, window_size=2, lang='chinese'):
    """_summary_
     Build a co-word matrix

    Args:
        documents (list): a list of documents
        window_size (int, optional):  Window size. Defaults to 2.
        lang (str, optional): setting the lang, only support chinese and english. Defaults to 'chinese'.

    Returns:
        dict: dict of co-word matrix
    """
    d = defaultdict(int)
    vocab = set()
    if lang == 'english':
        for document in documents:
            document = document.lower().split()
            for i in range(len(document)):
                token = document[i]
                vocab.add(token)  # add to vocab
                next_token = document[i + 1: i + 1 + window_size]
                for t in next_token:
                    key = tuple(sorted([t, token]))
                    d[key] += 1

    elif lang =='chinese':
        for document in documents:
            document = list(jieba.cut(document))
            # iterate over sentences
            for i in range(len(list(document))):
                token = document[i]
                vocab.add(token)  # add to vocab
                next_token = document[i + 1: i + 1 + window_size]
                for t in next_token:
                    key = tuple(sorted([t, token]))
                    d[key] += 1
                    
    # formulate the dictionary into dataframe
    vocab = sorted(vocab)  # sort vocab
    df = pd.DataFrame(data=np.zeros((len(vocab), len(vocab)), dtype=np.int16),
                      index=vocab,
                      columns=vocab)
    for key, value in d.items():
        df.at[key[0], key[1]] = value
        df.at[key[1], key[0]] = value
    return df
######################################################################################################################



class W2VModel(object):
    def __init__(self, corpus_file, encoding='utf-8', lang='chinese'):
        """
        initialize the W2VModel Class

        Args:
            corpus_file (str): The path of the corpus file
            lang (str, optional): setting the lang, only support chinese and english. Defaults to 'chinese'.
            encoding(str, optional): The encoding of corpus_file
        """
        self.lang = lang
        self.encoding = encoding
        self.corpus_file = corpus_file.replace('\\', '/')
        self.start = time.time()
        self.STOPWORDS_zh = read_yaml_dict(yfile='enzh_common_StopWords.yaml')['Dictionary']['chinese']
        self.STOPWORDS_en = read_yaml_dict(yfile='enzh_common_StopWords.yaml')['Dictionary']['english']
        
        

    def __preproces(self, documents):
        """
        preprocess the documents and return a list of string. In this function, we can merge the same meaning words into one unqiue word.
        
        Args:
            documents (list): list of str documents

        Returns:
            list: the cleaned document list
        """
        docs = []
        if self.lang=='english':
            for document in documents:
                document = [w for w in word_tokenize(document.lower()) if w not in self.STOPWORDS_en]
                docs.append(document)
            return docs
        elif self.lang=='chinese':
            for document in documents:
                words = jieba.cut(document)
                document = [w for w in words if w not in self.STOPWORDS_zh]
                docs.append(document)
            return docs
        else:
            assert 'Do not support {} language'.format(self.lang)
            
 

    def train(self, vector_size=100, window_size=6, min_count=6, save_dir='Word2Vec'):
        """_summary_
        train word2vec model for corpus
        
        Args:
            vector_size (int, optional): dimensionality of the word vectors.. Defaults to 100.
            window_size (int, optional): window size for word2vec. Defaults to 6.
            min_count (int, optional): Set the word to appear at least min_count times in the model. Defaults to 5.
            save_dir (str, optional): the directory to save the word2vec model. Defaults to 'Word2Vec'.
        
        Returns:
        """        
        
        documents = list(open(self.corpus_file, encoding=self.encoding).readlines())
        print('Start Preprocessing Corpus...')
        sents = self.__preproces(documents=documents)
        del documents
        gc.collect()
        
        
        print('Start Training! This may take a while. Please be patient...\n')
        sentences = []
        if self.lang=='english':
            phrase_model = Phrases(sents, min_count=10, threshold=1, connector_words=ENGLISH_CONNECTOR_WORDS)
            for sent in sents:
                sentences.append(phrase_model[sent])
        elif self.lang=='chinese':
            phrase_model = Phrases(sents, min_count=10, threshold=1)
            for sent in sents:
                sentences.append([w.replace('_', '') for w in phrase_model[sent]])
        else:
            sentences = sents
        del sents
        gc.collect()
        
        model = word2vec.Word2Vec(sentences, 
                                  vector_size=vector_size, 
                                  window=window_size, 
                                  min_count=min_count, 
                                  workers=multiprocessing.cpu_count())
        
        duration = int(time.time() - self.start)
        print('Training word2vec model took {} seconds\n'.format(duration))
        
        
        corpus_name = self.corpus_file.split('/')[-1].split('.')[0]
        model_name = f'{corpus_name}.{vector_size}.{window_size}.bin'

        output_dir = Path('output')
        output_dir.mkdir(exist_ok=True)
        save_dir_path = output_dir.joinpath(save_dir)
        save_dir_path.mkdir(exist_ok=True)

        w2v_bin_file = save_dir_path.joinpath(model_name)
        model.save(str(w2v_bin_file))
        print('Note: The Word2Vec model has been saved to {}\n'.format(save_dir_path))

######################################################################################   
        


def expand_dictionary(wv, seeddict, topn=100, save_dir='Word2Vec'):
    """
    According to the seed word file, select the top n words with the most similar semantics and save them in the directory save_dir.
    
    Args:
        wv (Word2VecKeyedVectors): the word embedding model
        seeddict (dict): the seed word dictionary. 
                         examples seeddict = {'pos': ['happy', 'wonderful', 'good'],
                                              'neg': ['bad', 'ugly', 'terrible'}
        topn (int, optional): Set the number of most similar words to retrieve to topn. Defaults to 100.
        save_dir (str, optional): the directory to save the candidate words. Defaults to 'Word2Vec'.
    
    Returns:
    """
    resultdict = dict()
    for seed_name in seeddict.keys():
        seedwords = seeddict[seed_name]
        simidx_scores = []
        similars_candidate_idxs = [] #the candidate words of seedwords
        dictionary = wv.key_to_index
        seedidxs = [] #transform word to index
        for seed in seedwords:
            if seed in dictionary:
                seedidx = dictionary[seed]
                seedidxs.append(seedidx)
        for seedidx in seedidxs:
            # sims_words such as [('by', 0.99984), ('or', 0.99982), ('an', 0.99981), ('up', 0.99980)]
            sims_words = wv.similar_by_word(seedidx, topn=topn)
            #Convert words to index and store them
            similars_candidate_idxs.extend([dictionary[sim[0]] for sim in sims_words])
        similars_candidate_idxs = set(similars_candidate_idxs)
        
        for idx in similars_candidate_idxs:
            score = wv.n_similarity([idx], seedidxs)
            simidx_scores.append((idx, score))
        simidxs = [w[0] for w in sorted(simidx_scores, key=lambda k:k[1], reverse=True)]

        simwords = [str(wv.index_to_key[idx]) for idx in simidxs][:topn]

        resultwords = []
        resultwords.extend(seedwords)
        resultwords.extend(simwords)
        
        resultdict[seed_name] = resultwords
        
        Path('output').mkdir(exist_ok=True)
        Path('output').joinpath(save_dir).mkdir(exist_ok=True)
        candidate_txt_file = Path('output').joinpath(save_dir, '{}.txt'.format(seed_name))
            
        with open(candidate_txt_file, 'w', encoding='utf-8') as f:
            for word in resultwords:
                f.write(word+'\n')

        print('Finish! {seed_name} candidates saved to output/{save_dir}'.format(seed_name=seed_name, save_dir=save_dir))



######################################################################################################################

class Glove(object):
    def __init__(self, corpus_file, lang='chinese'):
        """_summary_
        initialize the Glove model

        Args:
            corpus_file (str): the path of the corpus file
            lang (str, optional): setting the lang, only support chinese and english. Defaults to 'chinese'.
        """
        self.lang=lang
        self.corpus_file = corpus_file
        self.STOPWORDS_zh = read_yaml_dict(yfile='enzh_common_StopWords.yaml')['Dictionary']['chinese']
        self.STOPWORDS_en = read_yaml_dict(yfile='enzh_common_StopWords.yaml')['Dictionary']['english']
      



    def train(self, vector_size=50, save_dir='Glove', max_iter=25, min_count=6):
        """_summary_
        Train glove embeddings and save the model.

        Args:
            vector_size (int, optional): Dimensionality of the word vectors. Defaults to 50.
            save_dir (str, optional): . Defaults to 'Glove'.
            max_iter (int, optional):Number of training epochs. Defaults to 25.
            min_count (int, optional): Minimum word count threshold. Defaults to 6.

        Returns:
            
        """
        
        print('Create vocabulary for Glove.\n')
        output_name = self.corpus_file.replace('\\', '/').split('/')[-1].replace('.txt', '')
        text = open(self.corpus_file, encoding='utf-8').read()
        if self.lang=='chinese':
            words = list(jieba.cut(text))
            words = [w for w in words if w not in self.STOPWORDS_zh]
        else:
            words = text.split(' ')
            words = [w.lower() for w in words if w not in self.STOPWORDS_en]
        # 压缩vocab
        vocab = [k for (k, v) in Counter(words).items() if v >= min_count]
        
        

        # self.cooccurrence_matrix()
        print('Create cooccurrence matrix.\n')
        cv = CountVectorizer(ngram_range=(1, 1),
                             vocabulary=vocab)

        docs = [' '.join(words)]
        X = cv.fit_transform(docs)
        Xc = (X.T * X)
        Xc.setdiag(0)
        coo_matrix = Xc.toarray()

        
        print('Create cooccurrence matrix.\nTo complete this task, the code may take a significant amount of time, ranging from several minutes to potentially hours. Please be patient while the process runs.\n')
        start = time.time()
        glove_model = GloVe(n=vector_size, max_iter=max_iter)
        embeddings = glove_model.fit(coo_matrix)
        glove_embeddings = np.column_stack((np.array(vocab).reshape(-1, 1), embeddings))

        end = time.time()
        duration = round(end-start, 2)
        print('Finish training! Used {} s\n'.format(duration))
        
        print('Save the glove embeddings to a binary file\n')
        Path('output').mkdir(exist_ok=True)
        Path('output').joinpath(save_dir).mkdir(exist_ok=True)
    
        
  
        model_name = 'glove.{name}.{vector_size}.bin'.format(name=output_name, vector_size=vector_size)
        glove_file = str(Path('output').joinpath(save_dir, model_name))
        
        wv = OrderedDict({word: glove_embeddings[index][1:] for index, word in enumerate(vocab)})
        model = gensim.models.word2vec.Word2Vec(vector_size=vector_size, min_count=1)
        model.build_vocab_from_freq({word: 1 for word in vocab})
        model.wv.vectors = list(wv.values())
        model.wv.index_to_key = list(vocab)

        # save as binary file
        model.save(glove_file)
        
        
######################################################################################################################