__version__ = "2.1.0"

from .model import SoPmi, W2VModel, Glove, expand_dictionary, co_occurrence_matrix
from .similarity import jaccard_sim, minedit_sim, simple_sim, cosine_sim
from .stats import term_freq, readability, sentiment, sentiment_by_valence, word_in_context
from .mind import Text2Mind
from .io import get_files, read_file, read_files, detect_encoding, load_w2v, build_yaml_dict, read_yaml_dict, get_dict_list
#from .align import AlignModels
from .align2 import procrustes_align
from .psymatrix import PsyMatrixCalculator, CONCEPTS_PAIRS, plot_semantic_difference