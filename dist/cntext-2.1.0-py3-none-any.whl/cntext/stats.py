import re
import jieba
from collections import Counter
import numpy as np
import pandas as pd
from .io import read_yaml_dict
from nltk.tokenize import word_tokenize
import warnings


STOPWORDS_zh = read_yaml_dict(yfile='enzh_common_StopWords.yaml')['Dictionary']['chinese']
STOPWORDS_en = read_yaml_dict(yfile='enzh_common_StopWords.yaml')['Dictionary']['english']
zh_ADV_words = read_yaml_dict(yfile='enzh_common_AdvConj.yaml')['Dictionary']['zh_adv']
zh_CONJ_words = read_yaml_dict(yfile='enzh_common_AdvConj.yaml')['Dictionary']['zh_conj']



def zh_split_sentences(text):
    """
    Segment the chinese text into sentences
    
    Args:
        text (str): text to be segmented
        
    Returns:
        list of sentences
    """
    #split the chinese text into sentences
    # 1. 以句号分句
    text = re.sub('([。！；？;\?])([^”’])', "[[end]]", text)  # 单字符断句符
    text = re.sub('([。！？\?][”’])([^，。！？\?])', "[[end]]", text)
    text = re.sub('\s', '', text)
    # 如果双引号前有终止符，那么双引号才是句子的终点，把分句符\n放到双引号后，注意前面的几句都小心保留了双引号
    return text.split("[[end]]")


def en_split_sentences(text):
    # 定义分句的正则表达式
    pattern = r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!)\s'
    # 根据正则表达式分句
    sentences = re.split(pattern, text)
    # 如果最后一个句子没有结束符，则加上一个空格和句号作为结束符
    if not sentences[-1].endswith((".", "!", "?")):
        sentences[-1] += "."
    # 去掉句子中的空格
    sentences = [sentence.strip() for sentence in sentences]
    # 去掉空句子
    sentences = list(filter(None, sentences))
    return sentences

def cn_seg_sent(text):
    #split the chinese text into sentences
    text = re.sub('([。！；？;\?])([^”’])', "[[end]]", text)  # 单字符断句符
    text = re.sub('([。！？\?][”’])([^，。！？\?])', "[[end]]", text)
    text = re.sub('\s', '', text)
    # 如果双引号前有终止符，那么双引号才是句子的终点，把分句符\n放到双引号后，注意前面的几句都小心保留了双引号
    return text.split("[[end]]")



def term_freq(text, lang='chinese', return_df=False):
    """
    Calculates the word frequency

    :param language: "chinese" or "english"; default is "chinese"
    Args:
        text (str):text string
        lang (str, optional):setting the lang, only support chinese and english. Defaults to 'chinese'.
        return_df (bool, optional):return a dataframe or not. Defaults to False.

    Returns:
        _type_: _description_
    """

    # remove punctuation
    if lang=='chinese':
        #text = ''.join(re.findall('[\u4e00-\u9fa5]+', text))
        words = list(jieba.cut(text))
        words = [w for w in words if w not in STOPWORDS_zh]
    else:
        words = text.lower().split(" ")
        words = [w for w in words if w not in STOPWORDS_en]
        
    if return_df:
        return pd.DataFrame(Counter(words).items(), columns=['word', 'freq'])
    else:
        return Counter(words)




def readability(text, zh_advconj=None, lang='chinese'):
    """
    text readability, the larger the indicator, the higher the complexity of the article and the worse the readability.
    :param text: text string
    :param zh_advconj Chinese conjunctions and adverbs, receive list data type. By default, the built-in dictionary of cntext is used
    :param language: "chinese" or "english"; default is "chinese"
    ------------
    【English readability】english_readability = 4.71 x (characters/words) + 0.5 x (words/sentences) - 21.43；
    【Chinese readability】  Refer 【徐巍,姚振晔,陈冬华.中文年报可读性：衡量与检验[J].会计研究,2021(03):28-44.】
                 readability1  ---每个分句中的平均字数
                 readability2  ---每个句子中副词和连词所占的比例
                 readability3  ---参考Fog Index， readability3=(readability1+readability2)×0.5
                 以上三个指标越大，都说明文本的复杂程度越高，可读性越差。

    """
    if lang=='english':
        text = text.lower()
        #将浮点数、整数替换为num
        text = re.sub('\d+\.\d+|\.\d+', 'num', text)
        num_of_characters = len(text)
        #英文分词
        rgx = re.compile("(?:(?:[^a-zA-Z]+')|(?:'[^a-zA-Z]+))|(?:[^a-zA-Z']+)")
        num_of_words = len(re.split(rgx, text))
        #分句
        num_of_sentences = len(re.split('(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', text))
        ari = (
                4.71 * (num_of_characters / num_of_words)
                + 0.5 * (num_of_words / num_of_sentences)
                - 21.43
        )
        return {"readability": ari}
    if lang=='chinese':
        if zh_advconj:
            adv_conj_words = zh_advconj
        else:
            adv_conj_words = set(zh_ADV_words + zh_CONJ_words)
        zi_num_per_sent = []
        adv_conj_num_per_sent = []
        text = re.sub('\d+\.\d+|\.\d+', 'num', text)
        #【分句】
        sentences = cn_seg_sent(text)
        for sent in sentences:
            adv_conj_num = 0
            zi_num_per_sent.append(len(sent))
            words = list(jieba.cut(sent))
            for w in words:
                if w in adv_conj_words:
                    adv_conj_num+=1
            adv_conj_num_per_sent.append(adv_conj_num)
        readability1 = np.mean(zi_num_per_sent)
        readability2 = np.mean(adv_conj_num_per_sent)
        readability3 = (readability1+readability2)*0.5
        return {'readability1': readability1,
                'readability2': readability2,
                'readability3': readability3}





def sentiment(text, diction, lang='chinese', return_df=False):
    """
    Calculates the sentiment of each sentiment category words in text;
    the complex influence of intensity adverbs and negative words on emotion is not considered,
    
    Examples about diction parameter:
    
        diction = {'category1':  'category1 emotion word list',
                  'category2':  'category2 emotion word list',
                  'category3':  'category3 emotion word list',
                   ...
                }
    
    
    Args:
        text (str):  text string
        diction (dict): sentiment dictionary
        lang (str, optional): setting the lang, only support chinese and english. Defaults to 'chinese'.
        return_df (bool, optional): return a dataframe or not. Defaults to False.

    Returns:
        dict contains category and it's score
    """
    
     
    result_dict = dict()
    senti_categorys = diction.keys()

    stopword_num = 0
    for senti_category in senti_categorys:
        result_dict[senti_category+'_num'] = 0

    #sentence_num = len(re.split('[。！!？\?;；]+', text))-1
 
    if lang=='chinese':
        # using add_word to add chinese word in jieba
        for senti_category in senti_categorys:
            senti_category_words = diction[senti_category]
            for w in senti_category_words:
                try:
                    jieba.add_word(w)
                except:
                    pass


        sentence_num = len(zh_split_sentences(text))
        words = list(jieba.cut(text))
        word_num = len(words)
        for word in words:
            if word in STOPWORDS_zh:
                stopword_num+=1
            for senti_category in senti_categorys:
                if word in diction[senti_category]:
                    result_dict[senti_category+'_num'] +=  1

    else:
        sentence_num = len(re.split('(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', text.lower()))
        rgx = re.compile("(?:(?:[^a-zA-Z]+')|(?:'[^a-zA-Z]+))|(?:[^a-zA-Z']+)")
        words = re.split(rgx, text)
        word_num = len(words)
        for word in words:
            if word in STOPWORDS_en:
                stopword_num+=1
            for senti_category in senti_categorys:
                if word in diction[senti_category]:
                    result_dict[senti_category+'_num'] +=  1

    result_dict['stopword_num'] = stopword_num
    result_dict['word_num'] = word_num
    result_dict['sentence_num'] = sentence_num
    if return_df:
        return pd.DataFrame(result_dict, index=[0])
    return result_dict


    




def sentiment_by_valence(text, diction, lang='chinese', mean=False, return_df=False):
    """
    Calculate the occurrences of each sentiment category words in text;
    the complex influence of intensity adverbs and negative words on emotion is not considered.
    
    Args:
        text (str): text sring
        diction (dict): sentiment dictionary dataframe with valence.
        lang (str, optional):setting the lang, only support chinese and english. Defaults to 'chinese'.
        mean (boolean, optional): Whether calculate the average emotional information based on the number of words. Defaults to False.
        return_df (bool, optional): return a dataframe or not. Defaults to False.

    Returns:
        dict contains category and it's score
    """

    result = dict()
    result['text'] = text
    attrs = pd.DataFrame(diction).index
    for attr in attrs:
        result[attr] = 0
    

    if lang == 'chinese':
        words = list(jieba.cut(text))
        for word in words:
            if diction.get(word):
                for attr in attrs:
                    result[attr] = result[attr] + diction.get(word)[attr]


    else:
        text = text.lower()
        #rgx = re.compile("(?:(?:[^a-zA-Z]+')|(?:'[^a-zA-Z]+))|(?:[^a-zA-Z']+)")
        #words = re.split(rgx, text)
        try:
            words = word_tokenize(text)
        except:
            #print('你的电脑nltk没配置好，请观看视频https://www.bilibili.com/video/BV14A411i7DB')
            rgx = re.compile("(?:(?:[^a-zA-Z]+')|(?:'[^a-zA-Z]+))|(?:[^a-zA-Z']+)")
            words = re.split(rgx, text)

        for word in words:
            if diction.get(word):
                for attr in attrs:
                    result[attr] = result[attr] + diction.get(word)[attr]
      
    result['word_num'] = len(words)
    
    if mean==True:
        for attr in attrs:
            result[attr] = round(result[attr]/len(words), 3)
            
    if return_df:
        return pd.DataFrame(result, index=[0])
    return result 



def word_in_context(text, keywords, window=3, lang='chinese'):
    """
    Given text and keywords, the task is to find the text where the keyword appears
    Args:
        text (str): input document, string format
        keywords (list): keywords
        window (int): return the text where the keyword appears, default is 3, meaning return 3 word.
        lang (str, optional): setting the lang, only support chinese and english. Defaults to 'chinese'.

    Returns:
        list contains multiple dictionaries, where each dictionary contains the sentence, keyword, and the sentence where the keyword appears
    """
    if lang=='chinese':
        words = jieba.lcut(text.lower())
    else:
        try:
            words = word_tokenize(text.lower())
        except:
            warnings.warn("你应该安装nltk和对应的nltk_data, 请看B站https://www.bilibili.com/video/BV14A411i7DB")
            words = text.lower().split(' ')
            

    keywords = [w.lower() for w in keywords]
    kw_idxss = [[i for i, x in enumerate(words) if x == keyword] for keyword in keywords]
    rows = []
    for keyword, kw_idxs in zip(keywords, kw_idxss):
        for idx in kw_idxs:
            half = int((window-1)/2)
            start = max(0, idx - half)
            end = min(len(words), idx + half + 1)
            row = {'keyword': keyword, 
                   'context': ''.join(words[start: end]) if lang=='chinese' else ' '.join(words[start: end])
                      }
            rows.append(row)
    df = pd.DataFrame(rows)
    return df